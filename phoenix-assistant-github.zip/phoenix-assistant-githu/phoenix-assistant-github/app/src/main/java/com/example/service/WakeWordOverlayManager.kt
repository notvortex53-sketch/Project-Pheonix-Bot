package com.example.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Shows a small "Hey Phoenix" floating popup over whatever app is on screen,
 * the same way Google Assistant/Bixby show a mic overlay without opening
 * their full app. This needs the "Display over other apps" permission
 * (SYSTEM_ALERT_WINDOW) - unlike starting an Activity, drawing an overlay
 * window is NOT blocked by Android's background-activity-start
 * restrictions, so this works reliably even with the screen on and another
 * app in the foreground.
 */
class WakeWordOverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var statusText: TextView? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoHideRunnable: Runnable? = null

    fun canShowOverlay(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

    fun show(message: String = "Listening...") {
        mainHandler.post {
            if (!canShowOverlay()) return@post

            if (overlayView == null) {
                createOverlayView()
            }
            statusText?.text = message
            overlayView?.let { view ->
                if (view.windowToken == null && view.parent == null) {
                    try {
                        windowManager.addView(view, buildLayoutParams())
                        animateIn(view)
                    } catch (_: Exception) {
                        // Some OEM launchers restrict overlay windows further;
                        // fail silently rather than crash the wake-word service.
                    }
                }
            }
            scheduleAutoHide()
        }
    }

    fun updateMessage(message: String) {
        mainHandler.post { statusText?.text = message }
    }

    fun hide() {
        mainHandler.post {
            autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
            overlayView?.let { view ->
                if (view.parent != null) {
                    try {
                        windowManager.removeView(view)
                    } catch (_: Exception) {
                        // Already removed - nothing to do.
                    }
                }
            }
        }
    }

    private fun scheduleAutoHide() {
        autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
        val runnable = Runnable { hide() }
        autoHideRunnable = runnable
        // Safety net so the popup never gets stuck on screen if a command
        // never finishes processing for some reason.
        mainHandler.postDelayed(runnable, 12_000L)
    }

    private fun buildLayoutParams(): WindowManager.LayoutParams {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 80
        }
    }

    private fun createOverlayView() {
        val density = context.resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#1E1E2E"))
            }
            elevation = dp(8).toFloat()
        }

        val spinner = ProgressBar(context).apply {
            isIndeterminate = true
        }
        pill.addView(
            spinner,
            LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(10) }
        )

        val text = TextView(context).apply {
            text = "Listening..."
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        statusText = text
        pill.addView(text)

        overlayView = pill
    }

    private fun animateIn(view: View) {
        view.alpha = 0f
        view.translationY = -30f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 180L
            addUpdateListener {
                val fraction = it.animatedValue as Float
                view.alpha = fraction
                view.translationY = -30f * (1f - fraction)
            }
            start()
        }
    }
}
