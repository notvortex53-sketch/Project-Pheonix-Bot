package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user", "assistant", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoiceTriggered: Boolean = false,
    val actionType: String? = null, // e.g. "OPEN_SPOTIFY", "SEARCH_GOOGLE", "WRITE_NOTE", "OPEN_APP", "RUN_CODE"
    val actionPayload: String? = null,
    val actionStatus: String? = null // "SUCCESS", "FAILED", "PENDING", "SAFE_BLOCKED"
)

@Entity(tableName = "task_executions")
data class TaskExecutionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val actionType: String,
    val title: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String, // "SUCCESS", "SAFE_BLOCKED", "FAILED"
    val triggerSource: String, // "VOICE_HOTWORD", "VOICE_BUTTON", "CHAT_LLM", "MANUAL"
    val securityAudit: String = "PASSED_ZERO_EXPLOIT"
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isVoiceCreated: Boolean = false
)
