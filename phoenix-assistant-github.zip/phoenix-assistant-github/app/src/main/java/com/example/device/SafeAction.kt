package com.example.device

sealed class SafeAction(val typeName: String) {
    data class OpenSpotify(val query: String) : SafeAction("OPEN_SPOTIFY")
    data class SearchGoogle(val query: String) : SafeAction("SEARCH_GOOGLE")
    data class OpenNotepadAndWrite(val title: String, val content: String) : SafeAction("WRITE_NOTE")
    data class OpenApp(val appName: String) : SafeAction("OPEN_APP")
    data class SetTimer(val minutes: Int, val label: String) : SafeAction("SET_TIMER")
    data class RunCode(val language: String, val code: String) : SafeAction("RUN_CODE")
    data class OpenSettings(val settingType: String = "general") : SafeAction("OPEN_SETTINGS")
    data object OpenAssistant : SafeAction("OPEN_ASSISTANT")

    companion object {
        fun parseFromText(text: String): SafeAction? {
            val raw = text.trim()
            val lower = raw.lowercase()

            // 0. Trigger / Open Assistant
            // "TRIGGER_ASSISTANT", "hey phoenix", "wake up", "open assistant", "open phoenix"
            if (lower == "trigger_assistant" ||
                lower == "hey phoenix" ||
                lower == "phoenix" ||
                lower == "wake up" ||
                lower == "open assistant" ||
                lower == "open phoenix" ||
                lower == "launch assistant"
            ) {
                return OpenAssistant
            }

            // Clean conversational prefix fillers (e.g. "please open...", "can you open...", "could you...")
            val cleaned = lower
                .replace(Regex("""^(?:please|can you|could you|would you|i want to|go ahead and)\s+"""), "")
                .trim()

            // 1. Spotify / Play song
            // "open spotify and play stay by justin bieber", "play stay by justin bieber", "play starboy on spotify", "open spotify"
            val spotifyPlayPatterns = listOf(
                Regex("""(?:open\s+spotify\s+and\s+play|play\s+on\s+spotify|play\s+spotify|open\s+spotify\s+play)\s+(.+?)(?:\s+on\s+spotify)?$"""),
                Regex("""^play\s+(.+?)(?:\s+on\s+spotify)?$""")
            )
            for (pattern in spotifyPlayPatterns) {
                val match = pattern.find(cleaned)
                if (match != null) {
                    val song = match.groups[1]?.value?.trim() ?: ""
                    if (song.isNotBlank() && song != "music" && song != "songs" && song != "spotify") {
                        return OpenSpotify(song)
                    }
                    return OpenSpotify("Top Hits")
                }
            }
            if (cleaned == "open spotify" || cleaned == "launch spotify" || cleaned == "start spotify") {
                return OpenSpotify("Top Hits")
            }

            // 2. Notepad / Write note
            // "open notepad and write buy milk", "write a note called groceries buy milk", "take a note buy milk"
            val noteWritePattern = Regex("""(?:open\s+notepad\s+and\s+write|write\s+a\s+note\s+to|write\s+a\s+note|take\s+a\s+note|write\s+note|create\s+note)\s+(.+)""", RegexOption.IGNORE_CASE)
            val noteMatch = noteWritePattern.find(raw)
            if (noteMatch != null) {
                val noteText = noteMatch.groups[1]?.value?.trim() ?: ""
                val title = if (noteText.contains(":")) noteText.substringBefore(":").trim() else "Quick Note"
                val content = if (noteText.contains(":")) noteText.substringAfter(":").trim() else noteText
                return OpenNotepadAndWrite(title, content)
            }
            if (cleaned == "open notepad" || cleaned == "open notes" || cleaned == "open note pad") {
                return OpenNotepadAndWrite("Quick Note", "Opened notepad from voice assistant")
            }

            // 3. Search on Google
            // "search on google for best movies", "google who is elon musk", "search google for weather"
            val searchPattern = Regex("""(?:search\s+on\s+google\s+for|search\s+google\s+for|google\s+search\s+for|search\s+for|google)\s+(.+)""", RegexOption.IGNORE_CASE)
            val searchMatch = searchPattern.find(raw)
            if (searchMatch != null) {
                val query = searchMatch.groups[1]?.value?.trim() ?: ""
                if (query.isNotBlank()) return SearchGoogle(query)
            }

            // 4. Timer
            val timerPattern = Regex("""(?:set\s+(?:a\s+)?timer\s+for)\s+(\d+)\s*(?:min|minute|minutes)""", RegexOption.IGNORE_CASE)
            val timerMatch = timerPattern.find(cleaned)
            if (timerMatch != null) {
                val mins = timerMatch.groups[1]?.value?.toIntOrNull() ?: 5
                return SetTimer(mins, "Phoenix Timer")
            }

            // 5. System Settings
            if (cleaned == "open settings" || cleaned == "launch settings") {
                return OpenSettings("general")
            }
            if (cleaned.contains("wifi") && (cleaned.contains("open") || cleaned.contains("settings"))) {
                return OpenSettings("wifi")
            }
            if (cleaned.contains("bluetooth") && (cleaned.contains("open") || cleaned.contains("settings"))) {
                return OpenSettings("bluetooth")
            }

            // 6. Generic App Opening
            // "open camera", "open youtube", "open chrome", "open whatsapp", "launch calculator", etc.
            val appPattern = Regex("""^(?:open|launch|start)\s+(?:the\s+)?([a-zA-Z0-9\s]+?)(?:\s+app)?$""", RegexOption.IGNORE_CASE)
            val appMatch = appPattern.find(cleaned)
            if (appMatch != null) {
                val app = appMatch.groups[1]?.value?.trim() ?: ""
                if (app.isNotBlank()) {
                    if (app == "spotify") return OpenSpotify("Top Hits")
                    if (app == "notepad" || app == "notes") return OpenNotepadAndWrite("Quick Note", "Voice note")
                    if (app == "settings") return OpenSettings("general")
                    if (app == "assistant" || app == "phoenix") return OpenAssistant
                    return OpenApp(app)
                }
            }

            // 7. Code execution
            // "run code: 2 + 2", "execute code: ..."
            if (cleaned.startsWith("run code") || cleaned.startsWith("execute code")) {
                val code = raw.substringAfter(":").ifBlank { raw.substringAfter("code").trim() }
                return RunCode("kotlin", code)
            }

            return null
        }
    }
}
