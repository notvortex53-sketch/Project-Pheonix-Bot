package com.example.device

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.example.data.local.NoteEntity
import com.example.data.repository.PhoenixRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ExecutionResult(
    val success: Boolean,
    val actionType: String,
    val title: String,
    val details: String,
    val securityAudit: String = "PASSED_ZERO_EXPLOIT: Verified Safe Device Intent",
    val launchedExternally: Boolean = false
)

class SafeActionExecutor(
    private val context: Context,
    private val repository: PhoenixRepository
) {
    // Dangerous exploit keywords that must NEVER be executed
    private val exploitBlocklist = listOf(
        "su", "sudo", "rm -rf", "chmod", "sh", "bash", "busybox", "killall",
        "drop table", "exec(", "eval(", "dalvik", "runtime.getruntime",
        "file:///system", "file:///data/data", "content://call_log"
    )

    fun verifySafe(input: String): Boolean {
        val lower = input.lowercase()
        return exploitBlocklist.none { lower.contains(it) }
    }

    suspend fun execute(action: SafeAction, triggerSource: String = "VOICE"): ExecutionResult =
        withContext(Dispatchers.IO) {
            when (action) {
                is SafeAction.OpenSpotify -> executeSpotify(action.query)
                is SafeAction.SearchGoogle -> executeGoogleSearch(action.query)
                is SafeAction.OpenNotepadAndWrite -> executeOpenNotepadAndWrite(action.title, action.content, triggerSource)
                is SafeAction.OpenApp -> executeOpenApp(action.appName)
                is SafeAction.SetTimer -> executeSetTimer(action.minutes, action.label)
                is SafeAction.OpenSettings -> executeOpenSettings(action.settingType)
                is SafeAction.OpenAssistant -> executeOpenAssistant()
                is SafeAction.RunCode -> ExecutionResult(
                    success = true,
                    actionType = "RUN_CODE",
                    title = "Code Execution Requested",
                    details = "Routing code snippet to safe sandboxed evaluator.",
                    securityAudit = "SANDBOX_ISOLATED: Pure Local Evaluator"
                )
            }
        }

    private fun executeSpotify(query: String): ExecutionResult {
        if (!verifySafe(query)) {
            return ExecutionResult(
                success = false,
                actionType = "OPEN_SPOTIFY",
                title = "Security Guard Blocked Action",
                details = "Suspicious characters detected in media query.",
                securityAudit = "BLOCKED_UNSAFE"
            )
        }

        val pm = context.packageManager
        val isSpotifyInstalled = try {
            pm.getPackageInfo("com.spotify.music", 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        return try {
            if (isSpotifyInstalled) {
                // Launch Spotify with media search intent
                val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage("com.spotify.music")
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ExecutionResult(
                    success = true,
                    actionType = "OPEN_SPOTIFY",
                    title = "Opened Spotify",
                    details = "Playing '$query' on Spotify app.",
                    launchedExternally = true
                )
            } else {
                // Safe Web Spotify fallback
                val webUrl = "https://open.spotify.com/search/${Uri.encode(query)}"
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
                ExecutionResult(
                    success = true,
                    actionType = "OPEN_SPOTIFY",
                    title = "Opened Spotify Web Player",
                    details = "Spotify app not found. Opened search for '$query' via secure web player.",
                    launchedExternally = true
                )
            }
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                actionType = "OPEN_SPOTIFY",
                title = "Spotify Launch Error",
                details = "Failed to launch Spotify: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    private fun executeGoogleSearch(query: String): ExecutionResult {
        if (!verifySafe(query)) {
            return ExecutionResult(
                success = false,
                actionType = "SEARCH_GOOGLE",
                title = "Security Guard Blocked Action",
                details = "Query failed security validation.",
                securityAudit = "BLOCKED_UNSAFE"
            )
        }

        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ExecutionResult(
                success = true,
                actionType = "SEARCH_GOOGLE",
                title = "Google Search Executed",
                details = "Searched Google for: '$query'",
                launchedExternally = true
            )
        } catch (_: Exception) {
            // Fallback to direct URL intent
            try {
                val url = "https://www.google.com/search?q=${Uri.encode(query)}"
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
                ExecutionResult(
                    success = true,
                    actionType = "SEARCH_GOOGLE",
                    title = "Google Search Executed",
                    details = "Searched Google via browser for: '$query'",
                    launchedExternally = true
                )
            } catch (e2: Exception) {
                ExecutionResult(
                    success = false,
                    actionType = "SEARCH_GOOGLE",
                    title = "Search Failed",
                    details = "Unable to open browser: ${e2.localizedMessage}"
                )
            }
        }
    }

    private suspend fun executeOpenNotepadAndWrite(
        title: String,
        content: String,
        triggerSource: String
    ): ExecutionResult {
        if (!verifySafe(title) || !verifySafe(content)) {
            return ExecutionResult(
                success = false,
                actionType = "WRITE_NOTE",
                title = "Security Guard Blocked Note",
                details = "Content contains unverified executable patterns.",
                securityAudit = "BLOCKED_UNSAFE"
            )
        }

        // 1. Save directly into Phoenix's secure local Room database!
        val isVoice = triggerSource.contains("VOICE")
        val cleanTitle = if (title.isBlank() || title == "Quick Note") {
            if (content.length > 24) content.take(24) + "..." else content
        } else title

        repository.insertNote(
            NoteEntity(
                title = cleanTitle,
                content = content,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                isVoiceCreated = isVoice
            )
        )

        return ExecutionResult(
            success = true,
            actionType = "WRITE_NOTE",
            title = "Saved to Secure Notepad",
            details = "Note '$cleanTitle' saved locally on-device (private app storage): \"$content\"",
            securityAudit = "PASSED_ZERO_EXPLOIT: Local Offline Storage Only",
            launchedExternally = false
        )
    }

    private fun executeOpenApp(appName: String): ExecutionResult {
        if (!verifySafe(appName)) {
            return ExecutionResult(
                success = false,
                actionType = "OPEN_APP",
                title = "Security Guard Blocked App Launch",
                details = "Requested application target contains invalid tokens.",
                securityAudit = "BLOCKED_UNSAFE"
            )
        }

        val clean = appName.trim().lowercase()

        // Check if user is asking to open Phoenix Assistant
        if (clean == "assistant" || clean == "phoenix" || clean == "phoenix assistant") {
            return executeOpenAssistant()
        }

        val pm = context.packageManager

        // Known direct system intents with web fallbacks
        val specialIntent = when (clean) {
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            "settings" -> Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            "clock", "alarms", "alarm" -> Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            "calculator" -> (pm.getLaunchIntentForPackage("com.google.android.calculator")
                ?: pm.getLaunchIntentForPackage("com.android.calculator2")
                ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            "youtube" -> (pm.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            "chrome", "browser" -> (pm.getLaunchIntentForPackage("com.android.chrome")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            "maps" -> (pm.getLaunchIntentForPackage("com.google.android.apps.maps")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com"))).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            else -> null
        }

        if (specialIntent != null) {
            try {
                specialIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(specialIntent)
                return ExecutionResult(
                    success = true,
                    actionType = "OPEN_APP",
                    title = "Opened $appName",
                    details = "Launched system application '$appName'.",
                    launchedExternally = true
                )
            } catch (e: Exception) {
                // fall through to search installed packages
            }
        }

        // Search installed apps safely by label or package
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = pm.queryIntentActivities(mainIntent, 0)
            val matched = apps.firstOrNull { resolveInfo ->
                val label = resolveInfo.loadLabel(pm).toString().lowercase()
                val pkg = resolveInfo.activityInfo.packageName.lowercase()
                label.contains(clean) || pkg.contains(clean)
            }

            if (matched != null) {
                val launchIntent = pm.getLaunchIntentForPackage(matched.activityInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    return ExecutionResult(
                        success = true,
                        actionType = "OPEN_APP",
                        title = "Opened ${matched.loadLabel(pm)}",
                        details = "Launched package '${matched.activityInfo.packageName}' safely.",
                        launchedExternally = true
                    )
                }
            }

            return ExecutionResult(
                success = false,
                actionType = "OPEN_APP",
                title = "App Not Found",
                details = "Could not locate installed app matching '$appName'. Ensure it is installed on this device."
            )
        } catch (e: Exception) {
            return ExecutionResult(
                success = false,
                actionType = "OPEN_APP",
                title = "Launch Failed",
                details = "Security check passed, but launch failed: ${e.localizedMessage}"
            )
        }
    }

    private fun executeSetTimer(minutes: Int, label: String): ExecutionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ExecutionResult(
                success = true,
                actionType = "SET_TIMER",
                title = "Timer Set",
                details = "Set a timer for $minutes minutes ($label).",
                launchedExternally = true
            )
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                actionType = "SET_TIMER",
                title = "Timer Failed",
                details = "Clock app not available: ${e.localizedMessage}"
            )
        }
    }

    private fun executeOpenSettings(type: String): ExecutionResult {
        return try {
            val action = when (type.lowercase()) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(intent)
            ExecutionResult(
                success = true,
                actionType = "OPEN_SETTINGS",
                title = "Device Settings",
                details = "Opened system settings safely.",
                launchedExternally = true
            )
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                actionType = "OPEN_SETTINGS",
                title = "Settings Failed",
                details = "Unable to launch settings: ${e.localizedMessage}"
            )
        }
    }

    private fun executeOpenAssistant(): ExecutionResult {
        return try {
            val intent = Intent(context, com.example.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                putExtra("TRIGGER_SOURCE", "VOICE_HOTWORD")
            }
            context.startActivity(intent)
            ExecutionResult(
                success = true,
                actionType = "OPEN_ASSISTANT",
                title = "Phoenix Assistant Triggered",
                details = "Phoenix Assistant opened and active on screen.",
                securityAudit = "PASSED_ZERO_EXPLOIT: Internal Intent Launch",
                launchedExternally = false
            )
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                actionType = "OPEN_ASSISTANT",
                title = "Assistant Trigger Failed",
                details = "Could not bring assistant to front: ${e.localizedMessage}"
            )
        }
    }
}
