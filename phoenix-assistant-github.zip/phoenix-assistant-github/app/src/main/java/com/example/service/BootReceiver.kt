package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val settingsRepo = SettingsRepository(context)
            CoroutineScope(Dispatchers.IO).launch {
                val settings = settingsRepo.settings.value
                if (settings.backgroundServiceEnabled && settings.wakeWordEnabled) {
                    PhoenixVoiceService.startService(context)
                }
            }
        }
    }
}
