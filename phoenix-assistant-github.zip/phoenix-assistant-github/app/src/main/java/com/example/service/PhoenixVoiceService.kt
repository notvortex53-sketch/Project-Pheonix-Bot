package com.example.service

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.PhoenixApplication
import com.example.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class PhoenixVoiceService : Service() {

    companion object {
        const val CHANNEL_ID = "phoenix_voice_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.service.START_LISTENING"
        const val ACTION_STOP = "com.example.service.STOP_LISTENING"
        private const val RESTART_REQUEST_CODE = 4242

        fun startService(context: Context) {
            val intent = Intent(context, PhoenixVoiceService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, PhoenixVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isRunning = false

    // True only when the user (or settings) explicitly asked the service to stop.
    // Lets us tell the difference between "user turned it off" and "Android/OEM
    // killed the process", so we only self-heal in the latter case.
    private var explicitStop = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                explicitStop = true
                stopListeningAndService()
                return START_NOT_STICKY
            }
            else -> {
                explicitStop = false
                startForegroundWithNotification()
                startVoiceListening()
            }
        }
        return START_STICKY
    }

    // Called when the user swipes the app away from Recents. A plain foreground
    // service is NOT killed by this on stock Android, but many OEM battery
    // managers (MIUI, ColorOS, One UI, etc.) kill it anyway. Scheduling a
    // near-term alarm to relaunch the service is a safety net for that case,
    // on top of asking the user to exempt the app from battery optimization.
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (!explicitStop) {
            scheduleRestartAlarm()
        }
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification(
            title = "Phoenix Assistant Active",
            text = "Listening for 'Hey Phoenix' • 100% Offline Audio"
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val appOpenIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            appOpenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(title, text))
    }

    private fun startVoiceListening() {
        if (isRunning) return
        isRunning = true

        val app = application as PhoenixApplication
        val settings = app.settingsRepository.settings.value

        // Start continuous background listening for 'Hey Phoenix'
        app.voiceManager.startListening(
            continuous = true,
            offlineOnly = settings.offlineVoiceOnly
        )

        // Observe voice states to update the notification dynamically
        serviceScope.launch {
            app.voiceManager.voiceState.collectLatest { state ->
                when (state) {
                    VoiceState.WAKE_WORD_ACTIVATED -> {
                        updateNotification(
                            title = "Phoenix Assistant Triggered",
                            text = "Listening for command..."
                        )
                    }
                    VoiceState.PROCESSING_COMMAND -> {
                        updateNotification(
                            title = "Phoenix Assistant Executing",
                            text = "Processing voice request..."
                        )
                    }
                    VoiceState.LISTENING_FOR_WAKE_WORD -> {
                        updateNotification(
                            title = "Phoenix Assistant Active",
                            text = "Listening for 'Hey Phoenix' • 100% Offline Audio"
                        )
                    }
                    VoiceState.ERROR -> {
                        updateNotification(
                            title = "Phoenix Assistant Standby",
                            text = "Auto-reconnecting voice loop..."
                        )
                    }
                    VoiceState.IDLE -> {
                        updateNotification(
                            title = "Phoenix Assistant Paused",
                            text = "Standby mode"
                        )
                    }
                }
            }
        }
    }

    private fun stopListeningAndService() {
        isRunning = false
        val app = application as PhoenixApplication
        app.voiceManager.stopListening()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Schedules a short-delay alarm that relaunches this service if the OS kills it. */
    private fun scheduleRestartAlarm() {
        try {
            val restartIntent = Intent(applicationContext, PhoenixVoiceService::class.java).apply {
                action = ACTION_START
            }
            val pendingIntent = PendingIntent.getService(
                applicationContext,
                RESTART_REQUEST_CODE,
                restartIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // Inexact alarm on purpose: it doesn't require the SCHEDULE_EXACT_ALARM
            // permission on Android 12+, and being off by a second or two doesn't
            // matter for "resurrect the wake-word listener" purposes.
            val alarmManager = getSystemService(AlarmManager::class.java)
            alarmManager?.set(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1000L,
                pendingIntent
            )
        } catch (_: Exception) {
            // If scheduling fails there's nothing more we can do here; the
            // boot receiver and manual "start listening" toggle remain as
            // fallbacks the next time the device restarts or the app opens.
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Phoenix Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs local continuous wake-word detection for 'Hey Phoenix'"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        val shouldSelfHeal = isRunning && !explicitStop
        super.onDestroy()
        stopListeningAndService()
        serviceScope.cancel()
        if (shouldSelfHeal) {
            scheduleRestartAlarm()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
