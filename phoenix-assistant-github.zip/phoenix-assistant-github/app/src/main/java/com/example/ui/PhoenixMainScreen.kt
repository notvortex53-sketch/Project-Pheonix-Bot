package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SandboxScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekGreen
import com.example.ui.theme.SleekOnPrimaryContainer
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSurface
import com.example.ui.theme.SleekSurfaceVariant
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary
import com.example.voice.VoiceState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoenixMainScreen(
    viewModel: PhoenixMainViewModel = viewModel()
) {
    val context = LocalContext.current
    val chatMessages by viewModel.chatMessages.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val lastSandboxResult by viewModel.lastSandboxResult.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val audioRms by viewModel.audioRms.collectAsState()
    val transcription by viewModel.transcription.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasMicPermission = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (hasMicPermission && settings.wakeWordEnabled) {
            viewModel.startListening()
        }
    }

    LaunchedEffect(Unit) {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val ungranted = needed.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (ungranted.isNotEmpty()) {
            permissionLauncher.launch(ungranted.toTypedArray())
        } else {
            if (settings.wakeWordEnabled) {
                viewModel.startListening()
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedScreen = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = SleekBg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "SYSTEM ACTIVE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.2.sp,
                                color = SleekPrimary
                            )
                            Text(
                                text = "Phoenix",
                                fontWeight = FontWeight.Light,
                                fontSize = 28.sp,
                                letterSpacing = (-0.5).sp,
                                color = SleekTextPrimary
                            )
                        }
                    },
                    actions = {
                        // Offline Privacy lock button (from Sleek HTML design)
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SleekPrimaryContainer)
                                .clickable {
                                    if (hasMicPermission) {
                                        viewModel.triggerPushToTalk()
                                    } else {
                                        permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                    }
                                }
                                .testTag("privacy_shield_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "On-Device Offline Audio",
                                tint = SleekPrimary,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        // Settings quick action button (from Sleek HTML design)
                        Box(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SleekSurfaceVariant)
                                .clickable { viewModel.selectTab(PhoenixTab.SETTINGS) }
                                .testTag("settings_header_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = SleekTextSecondary,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SleekBg,
                        titleContentColor = SleekTextPrimary
                    )
                )
            },
            bottomBar = {
                if (!isExpandedScreen) {
                    PhoenixBottomNavigation(
                        selectedTab = selectedTab,
                        onSelectTab = { viewModel.selectTab(it) }
                    )
                }
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (isExpandedScreen) {
                    PhoenixNavigationRail(
                        selectedTab = selectedTab,
                        onSelectTab = { viewModel.selectTab(it) }
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .widthIn(max = 900.dp)
                ) {
                    when (selectedTab) {
                        PhoenixTab.CHAT -> ChatScreen(
                            messages = chatMessages,
                            isGenerating = isGenerating,
                            voiceState = voiceState,
                            audioRms = audioRms,
                            transcription = transcription,
                            onSendMessage = { viewModel.sendUserMessage(it) },
                            onVoiceTrigger = {
                                if (hasMicPermission) viewModel.triggerPushToTalk()
                                else permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                            },
                            onExecuteAction = { viewModel.executeActionDirect(it, "CHAT_REEXECUTE") },
                            onRunCodeInSandbox = {
                                viewModel.runCodeInSandbox(it)
                                viewModel.selectTab(PhoenixTab.SANDBOX)
                            },
                            onClearChat = { viewModel.clearChat() }
                        )

                        PhoenixTab.TASKS -> TasksScreen(
                            notes = notes,
                            onExecuteAction = { viewModel.executeActionDirect(it, "TASKS_DASHBOARD") },
                            onSaveNote = { title, content -> viewModel.saveNote(title, content) },
                            onDeleteNote = { viewModel.deleteNote(it) }
                        )

                        PhoenixTab.SANDBOX -> SandboxScreen(
                            lastResult = lastSandboxResult,
                            onRunCode = { code, lang -> viewModel.runCodeInSandbox(code, lang) }
                        )

                        PhoenixTab.HISTORY -> HistoryScreen(
                            tasks = tasks,
                            onClearTasks = { viewModel.clearTasks() },
                            onClearChat = { viewModel.clearChat() }
                        )

                        PhoenixTab.SETTINGS -> SettingsScreen(
                            settings = settings,
                            onUpdateApiKey = { viewModel.updateApiKey(it) },
                            onUpdateBaseUrl = { viewModel.updateBaseUrl(it) },
                            onUpdateModel = { viewModel.updateModel(it) },
                            onSetWakeWordEnabled = { viewModel.setWakeWordEnabled(it) },
                            onSetOfflineVoiceOnly = { viewModel.setOfflineVoiceOnly(it) },
                            onSetBackgroundServiceEnabled = { viewModel.setBackgroundServiceEnabled(it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PhoenixBottomNavigation(
    selectedTab: PhoenixTab,
    onSelectTab: (PhoenixTab) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp, top = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = SleekSurfaceVariant,
            shape = RoundedCornerShape(32.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val items = listOf(
                    Triple(PhoenixTab.CHAT, "Assistant", Icons.AutoMirrored.Filled.Chat),
                    Triple(PhoenixTab.TASKS, "Tasks", Icons.Default.Bolt),
                    Triple(PhoenixTab.SANDBOX, "Terminal", Icons.Default.Code),
                    Triple(PhoenixTab.HISTORY, "History", Icons.Default.History),
                    Triple(PhoenixTab.SETTINGS, "Settings", Icons.Default.Settings)
                )

                items.forEach { (tab, label, icon) ->
                    val isSelected = selectedTab == tab
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 4.dp, horizontal = 6.dp)
                            .testTag("nav_tab_${label.lowercase()}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(width = 44.dp, height = 28.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) SleekPrimaryContainer else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) SleekPrimary else SleekTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) SleekPrimary else SleekTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PhoenixNavigationRail(
    selectedTab: PhoenixTab,
    onSelectTab: (PhoenixTab) -> Unit
) {
    NavigationRail(
        containerColor = SleekSurfaceVariant,
        contentColor = SleekPrimary,
        modifier = Modifier.border(1.dp, SleekBorder)
    ) {
        val items = listOf(
            Triple(PhoenixTab.CHAT, "Assistant", Icons.AutoMirrored.Filled.Chat),
            Triple(PhoenixTab.TASKS, "Tasks", Icons.Default.Bolt),
            Triple(PhoenixTab.SANDBOX, "Terminal", Icons.Default.Code),
            Triple(PhoenixTab.HISTORY, "History", Icons.Default.History),
            Triple(PhoenixTab.SETTINGS, "Settings", Icons.Default.Settings)
        )

        Spacer(modifier = Modifier.height(16.dp))

        items.forEach { (tab, label, icon) ->
            val isSelected = selectedTab == tab
            NavigationRailItem(
                selected = isSelected,
                onClick = { onSelectTab(tab) },
                icon = { Icon(imageVector = icon, contentDescription = label) },
                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = SleekPrimary,
                    selectedTextColor = SleekPrimary,
                    unselectedIconColor = SleekTextSecondary,
                    unselectedTextColor = SleekTextSecondary,
                    indicatorColor = SleekPrimaryContainer
                )
            )
        }
    }
}
