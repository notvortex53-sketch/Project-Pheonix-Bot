package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class VoiceState {
    IDLE,
    LISTENING_FOR_WAKE_WORD,
    WAKE_WORD_ACTIVATED,
    PROCESSING_COMMAND,
    ERROR
}

class VoiceRecognitionManager(
    private val context: Context,
    private val onCommandReceived: (command: String, isHotwordTrigger: Boolean) -> Unit
) {
    companion object {
        private const val TAG = "PhoenixVoice"

        // Wake word variations for robust phoneme matching
        val WAKE_WORDS = listOf(
            "hey phoenix",
            "hey pheonix",
            "phoenix",
            "pheonix",
            "hi phoenix",
            "hi pheonix",
            "ok phoenix",
            "ok pheonix",
            "hey fenix",
            "fenix"
        )
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var restartJob: Job? = null

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _transcription = MutableStateFlow("")
    val transcription: StateFlow<String> = _transcription.asStateFlow()

    private val _isOfflinePreferred = MutableStateFlow(true)
    val isOfflinePreferred: StateFlow<Boolean> = _isOfflinePreferred.asStateFlow()

    private val _isContinuousListening = MutableStateFlow(false)
    val isContinuousListening: StateFlow<Boolean> = _isContinuousListening.asStateFlow()

    private var isPausedForSpeaking = false
    private var isListeningActive = false

    init {
        mainHandler.post {
            initRecognizer()
        }
    }

    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "SpeechRecognizer is not available on this device.")
            _voiceState.value = VoiceState.ERROR
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(PhoenixRecognitionListener())
            }
            Log.d(TAG, "SpeechRecognizer created successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create SpeechRecognizer: ${e.message}")
            _voiceState.value = VoiceState.ERROR
        }
    }

    fun startListening(continuous: Boolean = true, offlineOnly: Boolean = true) {
        _isOfflinePreferred.value = offlineOnly
        _isContinuousListening.value = continuous

        mainHandler.post {
            startListeningInternal()
        }
    }

    private fun startListeningInternal() {
        if (isPausedForSpeaking) {
            Log.d(TAG, "Speech recognition currently paused for speaker output.")
            return
        }

        restartJob?.cancel()

        if (speechRecognizer == null) {
            initRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            if (_isOfflinePreferred.value) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }

        try {
            speechRecognizer?.startListening(intent)
            isListeningActive = true
            if (_voiceState.value != VoiceState.WAKE_WORD_ACTIVATED) {
                _voiceState.value = VoiceState.LISTENING_FOR_WAKE_WORD
            }
            Log.d(TAG, "SpeechRecognizer started listening (continuous=${_isContinuousListening.value})")
        } catch (e: Exception) {
            Log.e(TAG, "Exception in startListeningInternal: ${e.message}")
            scheduleRestart(delayMs = 1000L, recreate = true)
        }
    }

    fun stopListening() {
        _isContinuousListening.value = false
        restartJob?.cancel()
        isListeningActive = false

        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.stopListening()
            } catch (_: Exception) {}
            _voiceState.value = VoiceState.IDLE
            _audioRms.value = 0f
            _transcription.value = ""
        }
    }

    fun triggerManualListening() {
        startListening(continuous = false, offlineOnly = _isOfflinePreferred.value)
    }

    fun pauseForSpeaking() {
        isPausedForSpeaking = true
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
            isListeningActive = false
            _audioRms.value = 0f
        }
    }

    fun resumeAfterSpeaking() {
        isPausedForSpeaking = false
        if (_isContinuousListening.value) {
            scheduleRestart(delayMs = 300L, recreate = false)
        }
    }

    private fun scheduleRestart(delayMs: Long, recreate: Boolean = false) {
        if (!_isContinuousListening.value || isPausedForSpeaking) return

        restartJob?.cancel()
        restartJob = scope.launch {
            delay(delayMs)
            if (_isContinuousListening.value && !isPausedForSpeaking) {
                mainHandler.post {
                    if (recreate || speechRecognizer == null) {
                        initRecognizer()
                    }
                    startListeningInternal()
                }
            }
        }
    }

    private fun handleSpeechResult(text: String, isPartial: Boolean) {
        if (isPausedForSpeaking) return

        val trimmed = text.trim()
        if (trimmed.isBlank()) return

        _transcription.value = trimmed
        val lower = trimmed.lowercase()

        // Check if any wake word appears in the speech text
        var matchedWakeWord: String? = null
        for (w in WAKE_WORDS) {
            if (lower.contains(w)) {
                matchedWakeWord = w
                break
            }
        }

        if (matchedWakeWord != null) {
            _voiceState.value = VoiceState.WAKE_WORD_ACTIVATED

            val idx = lower.indexOf(matchedWakeWord)
            val remainder = trimmed.substring(idx + matchedWakeWord.length)
                .trimStart(',', ':', '.', '!', ' ')
                .trim()

            if (remainder.isNotBlank()) {
                // Command was spoken together with wake word e.g. "Hey Phoenix open spotify"
                if (!isPartial) {
                    _voiceState.value = VoiceState.PROCESSING_COMMAND
                    Log.d(TAG, "Hotword triggered with command: '$remainder'")
                    onCommandReceived(remainder, true)
                }
            } else if (!isPartial) {
                // Wake word spoken alone e.g. "Hey Phoenix"
                _voiceState.value = VoiceState.WAKE_WORD_ACTIVATED
                Log.d(TAG, "Hotword triggered alone: '$matchedWakeWord'")
                onCommandReceived("TRIGGER_ASSISTANT", true)
            }
        } else if (!isPartial && !_isContinuousListening.value) {
            // Manual push-to-talk single command
            _voiceState.value = VoiceState.PROCESSING_COMMAND
            onCommandReceived(trimmed, false)
            stopListening()
        }
    }

    private inner class PhoenixRecognitionListener : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            isListeningActive = true
            if (_voiceState.value != VoiceState.WAKE_WORD_ACTIVATED && _voiceState.value != VoiceState.PROCESSING_COMMAND) {
                _voiceState.value = VoiceState.LISTENING_FOR_WAKE_WORD
            }
        }

        override fun onBeginningOfSpeech() {
            Log.d(TAG, "Beginning of speech detected.")
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (!isPausedForSpeaking) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _audioRms.value = normalized
            } else {
                _audioRms.value = 0f
            }
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            isListeningActive = false
            _audioRms.value = 0f
        }

        override fun onError(error: Int) {
            isListeningActive = false
            _audioRms.value = 0f

            val errorMsg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "No speech match (silence)"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout (silence)"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                SpeechRecognizer.ERROR_CLIENT -> "Client error"
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                SpeechRecognizer.ERROR_SERVER -> "Server error"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                else -> "Error code $error"
            }
            Log.d(TAG, "SpeechRecognizer onError: $errorMsg ($error)")

            if (_isContinuousListening.value) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        // Normal silence idle interval - quickly restart listening
                        scheduleRestart(delayMs = 250L, recreate = false)
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT -> {
                        // Hardware or service lockup - recreate instance with slight delay
                        scheduleRestart(delayMs = 600L, recreate = true)
                    }
                    SpeechRecognizer.ERROR_AUDIO -> {
                        // Audio resource released - recreate after backoff
                        scheduleRestart(delayMs = 1000L, recreate = true)
                    }
                    else -> {
                        scheduleRestart(delayMs = 500L, recreate = false)
                    }
                }
            } else {
                _voiceState.value = VoiceState.IDLE
            }
        }

        override fun onResults(results: Bundle?) {
            isListeningActive = false
            _audioRms.value = 0f

            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                // Find if any candidate matches the wake word or best candidate
                val matched = matches.firstOrNull { candidate ->
                    val lower = candidate.lowercase()
                    WAKE_WORDS.any { lower.contains(it) }
                } ?: matches.first()

                handleSpeechResult(matched, isPartial = false)
            }

            if (_isContinuousListening.value) {
                // Keep the continuous listening loop active!
                scheduleRestart(delayMs = 350L, recreate = false)
            } else {
                _voiceState.value = VoiceState.IDLE
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val partial = matches?.firstOrNull() ?: ""
            if (partial.isNotBlank()) {
                handleSpeechResult(partial, isPartial = true)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    fun destroy() {
        stopListening()
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (_: Exception) {}
        }
    }
}
